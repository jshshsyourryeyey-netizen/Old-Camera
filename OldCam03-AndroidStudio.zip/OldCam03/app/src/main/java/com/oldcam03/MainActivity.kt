package com.oldcam03

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.hardware.Camera
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Suppress("DEPRECATION")
class MainActivity : Activity(), SurfaceHolder.Callback {

    private lateinit var preview: SurfaceView
    private lateinit var recordButton: Button
    private lateinit var status: TextView

    private var camera: Camera? = null
    private var recorder: MediaRecorder? = null
    private var recording = false
    private var outputUri: android.net.Uri? = null

    private val permissions = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = android.widget.FrameLayout(this)
        preview = SurfaceView(this)
        root.addView(preview, android.widget.FrameLayout.LayoutParams(-1, -1))

        status = TextView(this).apply {
            text = "OLD CAM 0.3 MP"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(18, 18, 18, 18)
            typeface = android.graphics.Typeface.MONOSPACE
        }
        root.addView(status)

        recordButton = Button(this).apply {
            text = "●  REC"
            textSize = 16f
            setOnClickListener { if (recording) stopRecording() else startRecording() }
            alpha = 0.90f
        }
        val buttonParams = android.widget.FrameLayout.LayoutParams(230, 90)
        buttonParams.gravity = android.view.Gravity.BOTTOM or android.view.Gravity.CENTER_HORIZONTAL
        buttonParams.bottomMargin = 42
        root.addView(recordButton, buttonParams)

        setContentView(root)

        preview.holder.addCallback(this)

        if (!hasPermissions()) {
            requestPermissions(permissions, 20)
        }
    }

    private fun hasPermissions(): Boolean =
        permissions.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    override fun onRequestPermissionsResult(
        requestCode: Int, p: Array<out String>, results: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, p, results)
        if (requestCode == 20 && results.all { it == PackageManager.PERMISSION_GRANTED }) {
            openCamera()
        } else {
            Toast.makeText(this, "Se necesitan cámara y micrófono.", Toast.LENGTH_LONG).show()
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        if (hasPermissions()) openCamera()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        if (!recording) {
            try { camera?.stopPreview() } catch (_: Exception) {}
            try {
                camera?.setDisplayOrientation(90)
                camera?.setPreviewDisplay(holder)
                camera?.startPreview()
            } catch (_: Exception) {}
        }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        releaseCamera()
    }

    private fun openCamera() {
        if (camera != null) return
        try {
            camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_BACK)
            camera?.setDisplayOrientation(90)
            camera?.setPreviewDisplay(preview.holder)
            camera?.startPreview()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir la cámara: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun startRecording() {
        if (camera == null) openCamera()
        val c = camera ?: return

        try {
            c.unlock()

            recorder = MediaRecorder().apply {
                setCamera(c)

                // Deliberately old-school recording profile:
                // 640x480 ~= 0.3 MP, 15 fps, low bitrate.
                setAudioSource(MediaRecorder.AudioSource.CAMCORDER)
                setVideoSource(MediaRecorder.VideoSource.CAMERA)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)

                // AAC mono at 8 kHz gives the restricted microphone character.
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(8000)
                setAudioChannels(1)
                setAudioEncodingBitRate(24000)

                setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                setVideoSize(640, 480)
                setVideoFrameRate(15)
                setVideoEncodingBitRate(600000)

                setOutputFile(createVideoUri())
                setPreviewDisplay(preview.holder.surface)

                prepare()
                start()
            }

            recording = true
            recordButton.text = "■  STOP"
            status.text = "REC  640x480  15FPS"
            Toast.makeText(this, "Grabando...", Toast.LENGTH_SHORT).show()

        } catch (e: Exception) {
            Toast.makeText(this, "Error al grabar: ${e.message}", Toast.LENGTH_LONG).show()
            try { recorder?.reset(); recorder?.release() } catch (_: Exception) {}
            recorder = null
            try { c.lock() } catch (_: Exception) {}
        }
    }

    private fun createVideoUri(): android.net.Uri {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val name = "OLDCAM03_$stamp.mp4"

        return if (android.os.Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/OldCam03")
            }
            contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)!!
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
            val old = java.io.File(dir, "OldCam03")
            old.mkdirs()
            android.net.Uri.fromFile(java.io.File(old, name))
        }
    }

    private fun stopRecording() {
        try {
            recorder?.stop()
        } catch (_: Exception) {
            outputUri?.let {
                try { contentResolver.delete(it, null, null) } catch (_: Exception) {}
            }
        }

        try { recorder?.reset(); recorder?.release() } catch (_: Exception) {}
        recorder = null
        recording = false

        try { camera?.lock() } catch (_: Exception) {}
        try { camera?.startPreview() } catch (_: Exception) {}

        recordButton.text = "●  REC"
        status.text = "OLD CAM 0.3 MP"
        Toast.makeText(this, "Vídeo guardado en Movies/OldCam03", Toast.LENGTH_LONG).show()
    }

    private fun releaseCamera() {
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { camera?.stopPreview() } catch (_: Exception) {}
        try { camera?.release() } catch (_: Exception) {}
        camera = null
    }

    override fun onPause() {
        if (recording) stopRecording()
        super.onPause()
        releaseCamera()
    }
}
