# OldCam 0.3

Cámara Android orientada a producir vídeo directamente con características de cámaras digitales antiguas.

## Ajustes principales

- 640×480 (≈0.3 MP)
- 15 FPS
- H.264 a ~600 kbps
- AAC mono
- 8 kHz de audio
- 24 kbps de audio
- MP4
- Sin filtro de postproducción obligatorio
- Los vídeos se guardan en `Movies/OldCam03`

## Abrir

1. Instala Android Studio.
2. Abre la carpeta `OldCam03`.
3. Espera a que Gradle sincronice.
4. Conecta un Android o usa un emulador con cámara.
5. Pulsa Run.
6. Acepta cámara y micrófono.
7. Pulsa REC.

## Nota

Esta primera versión usa la API Camera antigua para maximizar compatibilidad con dispositivos Android antiguos. El resultado depende también de la cámara física del teléfono.

La siguiente evolución puede añadir un procesador de imagen en tiempo real para conseguir defectos característicos de cámaras CCD antiguas (balance de blancos irregular, ruido, blooming, clipping, colores, etc.) sin convertirlo simplemente en un filtro aplicado después.
